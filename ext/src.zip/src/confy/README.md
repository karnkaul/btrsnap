# confy

## Dumb and lightweight `.conf` parsing library.

[![Build Status](https://github.com/karnkaul/confy/actions/workflows/ci.yml/badge.svg)](https://github.com/karnkaul/confy/actions/workflows/ci.yml)

## Contributing

Pull/merge requests are welcome.

**[Original repository](https://github.com/karnkaul/confy)**
