cmake_minimum_required(VERSION 4.4)

if (CMAKE_VERSION VERSION_LESS "4.5.0")
  set(CMAKE_EXPERIMENTAL_CXX_IMPORT_STD "f35a9ac6-8463-4d38-8eec-5d6008153e7d")
  set(CMAKE_CXX_MODULE_STD ON)
endif()

set(CMAKE_CXX_STANDARD 23)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_DEBUG_POSTFIX "-d")

set(package_name clap)
project(${package_name} VERSION "0.1.3")

option(CLAP_BUILD_EXAMPLES "Build clap examples" ${PROJECT_IS_TOP_LEVEL})
option(CLAP_BUILD_TESTS "Build clap tests" ${PROJECT_IS_TOP_LEVEL})

add_subdirectory(lib)

if(CLAP_BUILD_EXAMPLES)
  add_subdirectory(examples)
endif()

if(CLAP_BUILD_TESTS)
  if(NOT TARGET klib::klib-test-main)
    include(FetchContent)
    FetchContent_Declare(klib
      GIT_REPOSITORY https://github.com/karnkaul/klib
      GIT_TAG feature/modules
      GIT_SHALLOW true
      SOURCE_DIR "${CMAKE_CURRENT_SOURCE_DIR}/ext/src/klib"
    )
    set(KLIB_UNIT_TEST ON)
    FetchContent_MakeAvailable(klib)
  endif()

  enable_testing()
  add_subdirectory(tests)
endif()
