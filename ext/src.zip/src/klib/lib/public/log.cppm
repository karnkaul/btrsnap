export module klib.log;

export import klib.core;

export namespace klib::log {
class File {
  public:
	File(File const&) = delete;
	File(File&&) = delete;
	auto operator=(File const&) = delete;
	auto operator=(File&&) = delete;

	explicit File(std::string path = "debug.log");
	~File();

	[[nodiscard]] auto is_attached() const -> bool;
	[[nodiscard]] auto get_path() const -> std::string_view { return m_path; }

  private:
	std::string m_path;
};
} // namespace klib::log

export namespace klib {
namespace log {
enum class Level : std::int8_t { Error, Warn, Info, Debug, COUNT_ };
auto const level_char_map = EnumMap<Level, char>{
	{Level::Error, 'E'},
	{Level::Warn, 'W'},
	{Level::Info, 'I'},
	{Level::Debug, 'D'},
};
using Colors = EnumMap<Level, std::optional<escape::Rgb>>;
auto const level_color_map = Colors{
	{Level::Error, escape::Rgb{241, 76, 76}},
	{Level::Warn, escape::Rgb{245, 245, 67}},
	{Level::Info, escape::Rgb{229, 229, 229}},
	{Level::Debug, escape::Rgb{170, 170, 170}},
};

inline constexpr auto debug_enabled_v = debug_v;

template <typename... Args>
struct BasicFmt : std::basic_format_string<char, Args...> {
	template <std::convertible_to<std::string_view> T>
	consteval BasicFmt(T const& t, std::source_location const& sloc = std::source_location::current())
		: std::basic_format_string<char, Args...>(t),
		  sloc(sloc) {}

	std::source_location sloc;
};

template <typename... Args>
using Fmt = BasicFmt<std::type_identity_t<Args>...>;

template <typename... Args>
void print(Level level, std::string_view tag, Fmt<Args...> const& fmt, Args&&... args);

template <typename... Args>
void error(std::string_view tag, Fmt<Args...> const& fmt, Args&&... args) {
	print(Level::Error, tag, fmt, std::forward<Args>(args)...);
}

template <typename... Args>
void warn(std::string_view tag, Fmt<Args...> const& fmt, Args&&... args) {
	print(Level::Warn, tag, fmt, std::forward<Args>(args)...);
}

template <typename... Args>
void info(std::string_view tag, Fmt<Args...> const& fmt, Args&&... args) {
	print(Level::Info, tag, fmt, std::forward<Args>(args)...);
}

template <typename... Args>
void debug(std::string_view tag, Fmt<Args...> const& fmt, Args&&... args) {
	if constexpr (!debug_enabled_v) {
		return;
	}
	print(Level::Debug, tag, fmt, std::forward<Args>(args)...);
}

// NOLINTNEXTLINE(performance-enum-size)
enum struct ThreadId : std::int64_t { Main = 0 };

struct Input {
	Level level{};
	std::string_view tag{};
	std::string_view message{};
	std::string_view file_name{};
	std::uint64_t line_number{};
};

constexpr auto debug_interpolate_format_v =
	std::string_view{"[{level}] [{tag}/{thread_id}] {message} [{timestamp}] [{file_name}:{line_number}]"};
constexpr auto ndebug_interpolate_format_v = std::string_view{"[{level}] [{tag}/{thread_id}] {message} [{timestamp}]"};
constexpr auto interpolate_format_v = debug_v ? debug_interpolate_format_v : ndebug_interpolate_format_v;

void set_max_level(Level level);
[[nodiscard]] auto get_max_level() -> Level;

void set_colors(std::optional<Colors> const& colors);
[[nodiscard]] auto get_colors() -> std::optional<Colors>;

void set_interpolate_format(std::string interpolate_format);

[[nodiscard]] auto get_thread_id() -> ThreadId;

[[nodiscard]] auto format(Input const& input) -> std::string;
void print(Input const& input);

class Tagged {
  public:
	explicit Tagged(std::string_view const tag, Level const max_level = Level::Debug)
		: max_level(max_level),
		  m_tag(tag) {}

	template <typename... Args>
	void error(Fmt<Args...> const& fmt, Args&&... args) const {
		log::error(m_tag, fmt, std::forward<Args>(args)...);
	}

	template <typename... Args>
	void warn(Fmt<Args...> const& fmt, Args&&... args) const {
		if (max_level < Level::Warn) {
			return;
		}
		log::warn(m_tag, fmt, std::forward<Args>(args)...);
	}

	template <typename... Args>
	void info(Fmt<Args...> const& fmt, Args&&... args) const {
		if (max_level < Level::Info) {
			return;
		}
		log::info(m_tag, fmt, std::forward<Args>(args)...);
	}

	template <typename... Args>
	void debug(Fmt<Args...> const& fmt, Args&&... args) const {
		if constexpr (!debug_enabled_v) {
			return;
		}
		if (max_level < Level::Debug) {
			return;
		}
		log::debug(m_tag, fmt, std::forward<Args>(args)...);
	}

	Level max_level{Level::Debug};

  private:
	std::string_view m_tag{};
};

template <typename Type>
class Typed : public Tagged {
  public:
	explicit Typed(Level max_level = Level::Debug) : Tagged(demangled_name<Type>(), max_level) {}
};
} // namespace log

template <typename... Args>
void log::print(Level const level, std::string_view const tag, Fmt<Args...> const& fmt, Args&&... args) {
	if (level > get_max_level()) {
		return;
	}
	auto const message = std::format(fmt, std::forward<Args>(args)...);
	auto const input = Input{
		.level = level,
		.tag = tag,
		.message = message,
		.file_name = fmt.sloc.file_name(),
		.line_number = fmt.sloc.line(),
	};
	print(input);
}
} // namespace klib
